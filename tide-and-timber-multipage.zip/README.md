# Tide & Timber — Multipage Static Site

Pages included:
- index.html (Home)
- search.html (MLS/IDX Search placeholder — replace iframe src)
- sell.html
- communities.html (with KPIs, schools & amenities)
- my-properties.html
- about.html
- contact.html (simple form w/ JS alert)
- blogs.html
- mortgage.html (working JS calculator)

How to deploy on GitHub Pages
1) Create a public repo and upload all files to the repo root.
2) Settings → Pages → Branch: main, Folder: /(root) → Save.
3) Your site will be live at https://<username>.github.io/<repo-name>/
