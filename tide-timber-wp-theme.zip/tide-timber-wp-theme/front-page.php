<?php get_header(); ?>
  <div id="root"></div>

  <script type="text/babel">
    const { useMemo, useState } = React;

    const BRAND = {
      name: "Tide & Timber Properties",
      tagline: "Panhandle locals. New-build specialists.",
      cityTag: "Freeport • Destin • 30A • Niceville",
    };

    const AGENT = {
      name: "Marcy — Commercial Broker & Realtor®",
      blurb:
        "Expanding the residential arm of our established commercial brokerage (Locate). We specialize in new construction and community-first guidance across Florida's Panhandle.",
      phone: "(850) 555-0126",
      email: "marcy@tideandtimber.com",
      office: "Freeport, FL • 35 min north of Destin",
      license: "FL Lic. BK3456789",
      photo: "https://images.unsplash.com/photo-1554151228-14d9def656e4?q=80&w=800&auto=format&fit=crop",
    };

    const fmt = (n) => n.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 });

    const STOCKS = [
      "https://images.unsplash.com/photo-1502005229762-cf1b2da7c6f0?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1494526585095-c41746248156?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1560185127-6ed189bf02f4?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1570129477492-45c003edd2be?q=80&w=1600&auto=format&fit=crop",
    ];

    const SAMPLE_LISTINGS = new Array(10).fill(0).map((_, i) => ({
      id: i + 1,
      photo: STOCKS[i % STOCKS.length],
      price: 430000 + i * 15000,
      address: [
        "123 Hammock Bay Blvd, Freeport, FL",
        "88 Pine Needle Ct, Freeport, FL",
        "204 Gulf Breeze Dr, Santa Rosa Beach, FL",
        "77 Harborview Cir, Destin, FL",
        "15 Sand Dune Ln, Santa Rosa Beach, FL",
      ][i % 5],
      beds: 3 + (i % 2),
      baths: 2 + (i % 2),
      sqft: 1800 + i * 80,
    }));

    const COMMUNITIES = [
      {
        slug: "freeport",
        name: "Freeport",
        banner: "https://images.unsplash.com/photo-1501183638710-841dd1904471?q=80&w=1600&auto=format&fit=crop",
        summary: "Booming with ~1,500 new builds in the city and surrounding areas. Great schools, family-friendly neighborhoods, and quick Bay & beach access.",
        metrics: { avgPrice: 498000, activeListings: 236, pricePerSqFt: 255, foreclosurePct: 0.4 },
        schools: ["Freeport Elementary", "Freeport Middle", "Freeport High"],
        amenities: ["LaGrange Bayou access", "Hammock Bay Town Center", "Parks & trails", "US-331/US-98 quick commute"],
      },
      {
        slug: "destin",
        name: "Destin",
        banner: "https://images.unsplash.com/photo-1494526585095-c41746248156?q=80&w=1600&auto=format&fit=crop",
        summary: "Beach-town energy, luxury new-build infill, and strong short-term rental demand. Attractive for investors and second homes.",
        metrics: { avgPrice: 875000, activeListings: 421, pricePerSqFt: 560, foreclosurePct: 0.2 },
        schools: ["Destin Elementary", "Destin Middle", "Fort Walton Beach High"],
        amenities: ["HarborWalk Village", "World-class fishing", "Marinas & Gulf access", "Premium dining & shops"],
      },
      {
        slug: "santarosa",
        name: "Santa Rosa Beach (30A)",
        banner: "https://images.unsplash.com/photo-1523217582562-09d0def993a6?q=80&w=1600&auto=format&fit=crop",
        summary: "Master-planned communities and upscale coastal builds along 30A with strong appreciation and lifestyle amenities.",
        metrics: { avgPrice: 1250000, activeListings: 512, pricePerSqFt: 720, foreclosurePct: 0.1 },
        schools: ["Dune Lakes Elementary", "Emerald Coast Middle", "South Walton High"],
        amenities: ["State parks & dune lakes", "30A trails & bike paths", "Boutique dining & shops", "Public beach access points"],
      },
      {
        slug: "niceville",
        name: "Niceville",
        banner: "https://images.unsplash.com/photo-1523217582562-09d0def993a6?q=80&w=1600&auto=format&fit=crop",
        summary: "Highly rated schools, convenient to Eglin AFB, steady new construction and neighborhood amenities.",
        metrics: { avgPrice: 540000, activeListings: 189, pricePerSqFt: 270, foreclosurePct: 0.3 },
        schools: ["Bluewater Elementary", "Ruckel Middle", "Niceville High"],
        amenities: ["Turkey Creek Park", "Bay access & boat ramps", "Community sports & events", "Convenient shopping corridors"],
      },
    ];

    const Kpi = ({ label, value, sub }) => (
      <div className="rounded-xl p-4 bg-white/80 backdrop-blur shadow-sm border border-slate-200">
        <div className="text-xs text-slate-500">{label}</div>
        <div className="text-xl font-semibold leading-tight">{value}</div>
        {sub && <div className="text-[11px] text-slate-400 mt-1">{sub}</div>}
      </div>
    );

    const Section = ({ title, children }) => (
      <section className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
        </div>
        {children}
      </section>
    );

    const ListingCard = ({ listing }) => (
      <div className="rounded-xl overflow-hidden bg-white border border-slate-200 shadow-sm">
        <img src={listing.photo} alt={listing.address} className="h-40 w-full object-cover" />
        <div className="p-3 space-y-1">
          <div className="text-base font-semibold">{fmt(listing.price)}</div>
          <div className="text-slate-700 text-xs">{listing.address}</div>
          <div className="text-slate-500 text-[11px]">
            {listing.beds} bd • {listing.baths} ba • {listing.sqft.toLocaleString()} sqft
          </div>
        </div>
      </div>
    );

    function HomePage() {
      return (
        <div className="space-y-6">
          <div className="rounded-2xl overflow-hidden border border-slate-200 shadow-sm">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1600&auto=format&fit=crop"
                alt="Emerald Coast neighborhood"
                className="w-full h-56 md:h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 text-white max-w-2xl">
                <div className="text-[10px] uppercase tracking-widest mb-1">Residential Division</div>
                <h1 className="text-xl md:text-3xl font-bold leading-tight">
                  Build your life on Florida&apos;s Emerald Coast
                </h1>
                <p className="mt-1 text-xs md:text-sm text-white/90">
                  Community-first guidance, new-build expertise, and a bigger marketing footprint backed by our commercial brokerage.
                </p>
              </div>
            </div>
          </div>

          <Section title="Quick Market Snapshot">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Kpi label="New Builds in Pipeline" value="~1,500" sub="Freeport & surrounding" />
              <Kpi label="Avg List Price (Freeport)" value={fmt(498000)} />
              <Kpi label="Avg List Price (Destin)" value={fmt(875000)} />
              <Kpi label="Our Response Time" value="< 1 hr" sub="7 days a week" />
            </div>
          </Section>

          <Section title="Featured New Builds">
            <div className="grid md:grid-cols-2 xl:grid-cols-5 gap-3">
              {SAMPLE_LISTINGS.map((l) => (
                <ListingCard key={l.id} listing={l} />
              ))}
            </div>
          </Section>
        </div>
      );
    }

    function MLSPage() {
      return (
        <div className="space-y-4">
          <Section title="MLS Home Search">
            <div className="rounded-xl overflow-hidden border border-slate-200 bg-white shadow-sm">
              <iframe title="MLS/IDX Search" src="https://example-idx-provider.com/search?area=Emerald+Coast" className="w-full h-[520px]"></iframe>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">We can integrate Flexmls, IDX Broker, iHomefinder, or your MLS-approved vendor here.</p>
          </Section>
        </div>
      );
    }

    function SellPage() {
      return (
        <div className="space-y-4">
          <Section title="Sell with Tide & Timber">
            <div className="rounded-xl p-4 bg-white border border-slate-200 shadow-sm space-y-2 text-sm">
              <p>Leverage our commercial-grade marketing engine—professional media, paid distribution, and hyper-local audience targeting across the Panhandle.</p>
              <ul className="list-disc list-inside text-slate-700 space-y-1">
                <li>Agent-led pricing strategy using live MLS comps</li>
                <li>Builder & developer relationships to reach relocation buyers</li>
                <li>Staging consult, 3D tours, drone + floor plans</li>
                <li>Weekly performance reporting</li>
              </ul>
            </div>
          </Section>
        </div>
      );
    }

    function CommunityDetail({ c }) {
      return (
        <div className="space-y-4">
          <div className="rounded-xl overflow-hidden border border-slate-200 shadow-sm">
            <img src={c.banner} alt={c.name + ' banner'} className="w-full h-40 md:h-52 object-cover" />
          </div>
          <div className="grid lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 space-y-4">
              <div className="rounded-xl p-4 bg-white shadow-sm border border-slate-200">
                <h3 className="text-base font-semibold mb-2">Market Snapshot</h3>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <Kpi label="Avg Listing Price" value={fmt(c.metrics.avgPrice)} />
                  <Kpi label="Active Listings" value={c.metrics.activeListings.toLocaleString()} />
                  <Kpi label="Price / Sq Ft" value={fmt(c.metrics.pricePerSqFt)} sub="median" />
                  <Kpi label="Foreclosures" value={c.metrics.foreclosurePct + '%'} sub="of active" />
                </div>
              </div>
              <div className="rounded-xl p-4 bg-white shadow-sm border border-slate-200">
                <h3 className="text-base font-semibold mb-2">Overview</h3>
                <p className="text-slate-700 text-sm">{c.summary}</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="rounded-xl p-4 bg-white shadow-sm border border-slate-200">
                <h4 className="font-semibold mb-2 text-sm">Schools</h4>
                <ul className="space-y-1 text-slate-700 list-disc list-inside text-sm">
                  {c.schools.map((s) => (<li key={s}>{s}</li>))}
                </ul>
              </div>
              <div className="rounded-xl p-4 bg-white shadow-sm border border-slate-200">
                <h4 className="font-semibold mb-2 text-sm">Amenities</h4>
                <ul className="space-y-1 text-slate-700 list-disc list-inside text-sm">
                  {c.amenities.map((a) => (<li key={a}>{a}</li>))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      );
    }

    function CommunitiesPage() {
      const [sel, setSel] = useState(COMMUNITIES[0].slug);
      const current = COMMUNITIES.find((c) => c.slug === sel);
      return (
        <div className="space-y-4">
          <Section title="Communities & Market Stats">
            <div className="flex flex-wrap gap-2 mb-2">
              {COMMUNITIES.map((c) => (
                <button key={c.slug} onClick={() => setSel(c.slug)} className={'px-3 py-1.5 rounded-lg border text-xs ' + (sel === c.slug ? 'bg-slate-900 text-white border-slate-900' : 'bg-white hover:bg-slate-50 border-slate-200')}>{c.name}</button>
              ))}
            </div>
            <CommunityDetail c={current} />
          </Section>
        </div>
      );
    }

    function MyPropertiesPage() {
      return (
        <div className="space-y-4">
          <Section title="Our Listings">
            <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-3">
              {SAMPLE_LISTINGS.slice(0, 8).map((l) => (<ListingCard key={l.id} listing={l} />))}
            </div>
          </Section>
        </div>
      );
    }

    function AboutPage() {
      return (
        <div className="space-y-4">
          <Section title="About Tide & Timber">
            <div className="rounded-xl p-4 bg-white border border-slate-200 shadow-sm grid md:grid-cols-[140px,1fr] gap-4 items-start text-sm">
              <img src={AGENT.photo} alt="Marcy headshot" className="w-36 h-36 object-cover rounded-xl" />
              <div>
                <h3 className="text-base font-semibold">{AGENT.name}</h3>
                <div className="text-xs text-slate-600">{AGENT.office} • {AGENT.license}</div>
                <p className="mt-2 text-slate-700">{AGENT.blurb}</p>
                <div className="mt-3 grid sm:grid-cols-3 gap-3">
                  <Kpi label="Commercial Experience" value="10+ yrs" />
                  <Kpi label="Avg DOM (Seller)" value="< 20 days" />
                  <Kpi label="Areas Covered" value="Freeport • Destin • 30A • Niceville" />
                </div>
              </div>
            </div>
          </Section>
        </div>
      );
    }

    function ContactPage() {
      const [form, setForm] = useState({ name: '', email: '', phone: '', timeframe: '', message: '' });
      const [sent, setSent] = useState(false);
      const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });
      const submit = (e) => { e.preventDefault(); setSent(true); setTimeout(()=>setSent(false), 3000); setForm({ name:'', email:'', phone:'', timeframe:'', message:''}); };
      return (
        <div className="space-y-4">
          <Section title="Contact Us">
            <div className="grid lg:grid-cols-3 gap-4">
              <div className="rounded-xl p-4 bg-white border border-slate-200 shadow-sm space-y-1 text-sm">
                <div className="text-xs text-slate-500">Agent</div>
                <div className="text-base font-semibold">{AGENT.name}</div>
                <div className="text-slate-700">{AGENT.phone}</div>
                <div className="text-slate-700">{AGENT.email}</div>
                <div className="text-slate-700">{AGENT.office}</div>
                <div className="text-slate-700">Mon–Sat 8a–7p</div>
              </div>
              <form onSubmit={submit} className="lg:col-span-2 rounded-xl p-4 bg-white border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <input name="name" value={form.name} onChange={handle} placeholder="Full name" className="rounded-lg border p-2" required />
                <input name="email" value={form.email} onChange={handle} placeholder="Email" className="rounded-lg border p-2" type="email" required />
                <input name="phone" value={form.phone} onChange={handle} placeholder="Phone" className="rounded-lg border p-2" />
                <input name="timeframe" value={form.timeframe} onChange={handle} placeholder="Buying timeframe" className="rounded-lg border p-2" />
                <textarea name="message" value={form.message} onChange={handle} placeholder="How can we help?" className="sm:col-span-2 rounded-lg border p-2 h-28"></textarea>
                <button className="sm:col-span-2 rounded-lg bg-slate-900 text-white p-2.5 font-medium">Submit</button>
                {sent && <div className="sm:col-span-2 text-green-600 text-sm">Thanks! We’ll be in touch shortly.</div>}
              </form>
            </div>
          </Section>
        </div>
      );
    }

    function BlogsPage() {
      const POSTS = [
        { title: "Freeport New-Build Guide: Lots, Builders & Timelines", excerpt: "From contract to closing—what to expect along the Bay.", cover: "https://images.unsplash.com/photo-1507089947368-19c1da9775ae?q=80&w=1600&auto=format&fit=crop" },
        { title: "Moving to the Emerald Coast with Kids: Schools & Neighborhoods", excerpt: "Top-rated schools and family amenities from Freeport to 30A.", cover: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?q=80&w=1600&auto=format&fit=crop" },
        { title: "Investor Snapshot: Destin & 30A Short-Term Rental Rules", excerpt: "What to know before you buy a STR on the coast.", cover: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?q=80&w=1600&auto=format&fit=crop" },
      ];
      return (
        <div className="space-y-4">
          <Section title="Latest from the Blog">
            <div className="grid md:grid-cols-3 gap-3">
              {POSTS.map((p) => (
                <article key={p.title} className="rounded-xl overflow-hidden border border-slate-200 bg-white shadow-sm">
                  <img src={p.cover} alt="blog cover" className="h-36 w-full object-cover" />
                  <div className="p-3">
                    <h3 className="font-semibold text-sm">{p.title}</h3>
                    <p className="text-xs text-slate-600 mt-1">{p.excerpt}</p>
                    <button className="mt-2 text-xs font-medium underline">Read more</button>
                  </div>
                </article>
              ))}
            </div>
          </Section>
        </div>
      );
    }

    function Header() {
      return (
        <div className="px-4 md:px-6 py-3 border-b bg-white/80 backdrop-blur sticky top-0 z-30">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-xl md:text-2xl font-bold tracking-tight">{BRAND.name}</div>
              <div className="text-xs text-slate-600">{BRAND.tagline} • {BRAND.cityTag}</div>
            </div>
            <div className="hidden md:flex items-center gap-5 text-xs">
              <div className="flex items-center gap-1">{AGENT.phone}</div>
              <div className="flex items-center gap-1">{AGENT.email}</div>
              <div className="flex items-center gap-1">{AGENT.office}</div>
            </div>
          </div>
        </div>
      );
    }

    function Sidebar({ current, onSelect }) {
      const items = [
        ["home", "Home"],
        ["search", "Search"],
        ["sell", "Sell"],
        ["communities", "Communities"],
        ["myprops", "My Properties"],
        ["about", "About"],
        ["contact", "Contact Us"],
        ["blogs", "Blogs"],
        ["mortgage", "Mortgage Calculator"],
      ];
      return (
        <aside className="w-full md:w-56 border-r bg-white/70 backdrop-blur">
          <nav className="p-2 md:p-3 space-y-1 scroll-thin max-h-[calc(100vh-64px)] overflow-auto">
            {items.map(([key, label]) => (
              <button key={key} onClick={() => onSelect(key)} className={"w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition shadow-sm border text-sm " + (current === key ? "bg-slate-900 text-white border-slate-900" : "bg-white hover:bg-slate-50 border-slate-200")}>
                <span className="font-medium">{label}</span>
              </button>
            ))}
          </nav>
          <div className="p-3">
            <div className="rounded-xl p-3 bg-slate-900 text-white">
              <div className="text-[10px] uppercase tracking-wider text-slate-300">Talk to a Local Expert</div>
              <div className="font-semibold mt-1 text-sm">{AGENT.name}</div>
              <div className="text-[11px] text-slate-300">{AGENT.license}</div>
              <div className="mt-2 text-xs">{AGENT.office}</div>
              <a href={"tel:" + AGENT.phone.replace(/[^\d]/g, "")} className="inline-block mt-3 rounded-lg px-3 py-2 bg-white text-slate-900 font-medium text-xs">Call {AGENT.phone}</a>
            </div>
          </div>
        </aside>
      );
    }

    function App() {
      const [page, setPage] = useState("home");
      return (
        <div className="min-h-screen">
          <Header />
          <div className="mx-auto max-w-7xl grid md:grid-cols-[230px,1fr] gap-0">
            <Sidebar current={page} onSelect={setPage} />
            <main className="p-4 md:p-6">
              {page === "home" && <HomePage />}
              {page === "search" && <MLSPage />}
              {page === "sell" && <SellPage />}
              {page === "communities" && <CommunitiesPage />}
              {page === "myprops" && <MyPropertiesPage />}
              {page === "about" && <AboutPage />}
              {page === "contact" && <ContactPage />}
              {page === "blogs" && <BlogsPage />}
              {page === "mortgage" && (<Section title="Mortgage Calculator"><MortgageCalculator /></Section>)}
            </main>
          </div>
          <footer className="border-t p-5 text-center text-xs text-slate-600 bg-white/70 backdrop-blur">
            © {new Date().getFullYear()} {BRAND.name}. Residential division of Locate Commercial Brokerage.
          </footer>
        </div>
      );
    }

    function MortgageCalculator() {
      const [price, setPrice] = useState(450000);
      const [down, setDown] = useState(10);
      const [rate, setRate] = useState(6.5);
      const [years, setYears] = useState(30);
      const principal = useMemo(() => price * (1 - down / 100), [price, down]);
      const monthlyRate = useMemo(() => rate / 100 / 12, [rate]);
      const n = years * 12;
      const monthly = useMemo(() => {
        if (!n || !principal) return 0;
        if (monthlyRate === 0) return principal / n;
        return (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -n));
      }, [principal, monthlyRate, n]);

      return (
        <div className="grid md:grid-cols-2 gap-4">
          <div className="rounded-xl p-4 bg-white shadow-sm border border-slate-200 grid grid-cols-2 gap-3 text-sm">
            <label>Home Price<input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value)||0)} className="mt-1 w-full rounded-lg border p-2" /></label>
            <label>Down Payment (%)<input type="number" value={down} onChange={(e) => setDown(Number(e.target.value)||0)} className="mt-1 w-full rounded-lg border p-2" /></label>
            <label>Rate (%)<input type="number" step="0.01" value={rate} onChange={(e) => setRate(Number(e.target.value)||0)} className="mt-1 w-full rounded-lg border p-2" /></label>
            <label>Term (years)<input type="number" value={years} onChange={(e) => setYears(Number(e.target.value)||0)} className="mt-1 w-full rounded-lg border p-2" /></label>
          </div>
          <div className="rounded-xl p-4 bg-slate-900 text-white shadow-md">
            <div className="text-xs text-slate-300">Estimated Monthly Payment</div>
            <div className="text-3xl font-bold mt-1">{(monthly || 0).toLocaleString(undefined, { style: "currency", currency: "USD" })}</div>
            <div className="mt-3 grid grid-cols-3 gap-3 text-sm">
              <Kpi label="Loan Amount" value={fmt(principal || 0)} />
              <Kpi label="Rate" value={`${rate}%`} />
              <Kpi label="Term" value={`${years} yrs`} />
            </div>
            <p className="text-[11px] text-slate-300 mt-3">Estimate only. Taxes, insurance, HOA, and PMI not included.</p>
          </div>
        </div>
      );
    }

    ReactDOM.createRoot(document.getElementById("root")).render(<App />);
  </script>

<?php get_footer(); ?>
