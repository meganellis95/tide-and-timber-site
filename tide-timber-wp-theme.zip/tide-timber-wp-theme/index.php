<?php get_header(); ?>
  <main class="p-6">
    <h1 class="text-2xl font-bold">Tide & Timber Residential</h1>
    <p class="text-slate-600 mt-2">Set a static front page to use the full React app (Appearance → Customize → Homepage Settings).</p>
  </main>
<?php get_footer(); ?>
