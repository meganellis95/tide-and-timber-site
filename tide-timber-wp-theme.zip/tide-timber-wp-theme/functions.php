<?php
/**
 * Tide & Timber Residential — functions and setup
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action('after_setup_theme', function() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  register_nav_menus([
    'primary' => __('Primary Menu', 'tide-timber-residential'),
  ]);
});

add_action('wp_enqueue_scripts', function() {
  // Tailwind CDN
  wp_enqueue_script('tailwind', 'https://cdn.tailwindcss.com', [], null, false);

  // React 18 UMD + ReactDOM
  wp_enqueue_script('react', 'https://unpkg.com/react@18/umd/react.development.js', [], null, true);
  wp_enqueue_script('react-dom', 'https://unpkg.com/react-dom@18/umd/react-dom.development.js', ['react'], null, true);

  // Babel (so JSX in template works without build step)
  wp_enqueue_script('babel', 'https://unpkg.com/@babel/standalone/babel.min.js', [], null, true);

  // Pass site data to JS if needed later
  wp_localize_script('react', 'tideTimberData', [
    'homeUrl' => home_url('/'),
    'siteName' => get_bloginfo('name'),
  ]);
});
