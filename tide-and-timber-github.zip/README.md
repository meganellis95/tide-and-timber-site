# Tide & Timber — GitHub Pages Bundle

Static home page for the Tide & Timber site.

## Files
- `index.html`
- `style.css`

## Deploy
1. Create a public GitHub repo.
2. Upload these files to the root.
3. Enable GitHub Pages in repo settings.
